from qpyr.main import main
